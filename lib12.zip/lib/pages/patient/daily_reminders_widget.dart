import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:intl/intl.dart';

class DailyRemindersWidget extends StatelessWidget {
  const DailyRemindersWidget({super.key});

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return SizedBox.shrink();

    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(Icons.alarm, color: Colors.orange[600], size: 24),
                SizedBox(width: 8),
                Text(
                  'Today\'s Reminders',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.orange[700],
                  ),
                ),
              ],
            ),
            SizedBox(height: 16),
            StreamBuilder<QuerySnapshot>(
              stream: FirebaseFirestore.instance
                  .collection('notifications')
                  .where('userId', isEqualTo: user.uid)
                  .where('isImmediate', isEqualTo: true)
                  .where('isRead', isEqualTo: false)
                  .orderBy('timestamp', descending: true)
                  .limit(5)
                  .snapshots(),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return Center(child: CircularProgressIndicator());
                }

                if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
                  return Column(
                    children: [
                      Icon(Icons.check_circle,
                          color: Colors.green[600], size: 48),
                      SizedBox(height: 8),
                      Text(
                        'All caught up!',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          color: Colors.green[700],
                        ),
                      ),
                      Text(
                        'No pending reminders for today',
                        style: TextStyle(color: Colors.grey[600], fontSize: 12),
                      ),
                    ],
                  );
                }

                return Column(
                  children: snapshot.data!.docs.map((doc) {
                    final data = doc.data() as Map<String, dynamic>;
                    final type = data['type'] ?? '';
                    final title = data['title'] ?? '';
                    final message = data['message'] ?? '';
                    final scheduledTime = data['scheduledTime'] ?? '';

                    return Container(
                      margin: EdgeInsets.only(bottom: 8),
                      padding: EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: _getReminderColor(type),
                        borderRadius: BorderRadius.circular(8),
                        border:
                            Border.all(color: _getReminderBorderColor(type)),
                      ),
                      child: Row(
                        children: [
                          Icon(
                            _getReminderIcon(type),
                            color: _getReminderIconColor(type),
                            size: 20,
                          ),
                          SizedBox(width: 8),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  title,
                                  style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    fontSize: 12,
                                  ),
                                ),
                                Text(
                                  message,
                                  style: TextStyle(fontSize: 11),
                                ),
                                if (scheduledTime.isNotEmpty)
                                  Text(
                                    'Time: $scheduledTime',
                                    style: TextStyle(
                                      fontSize: 10,
                                      color: Colors.grey[600],
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                              ],
                            ),
                          ),
                          IconButton(
                            onPressed: () async {
                              await doc.reference.update({'isRead': true});
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(
                                  content: Text('Reminder marked as read'),
                                  backgroundColor: Colors.green[600],
                                  behavior: SnackBarBehavior.floating,
                                ),
                              );
                            },
                            icon: Icon(Icons.check,
                                color: Colors.green[600], size: 16),
                          ),
                        ],
                      ),
                    );
                  }).toList(),
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  Color _getReminderColor(String type) {
    switch (type) {
      case 'meal_reminder':
        return Colors.orange[50]!;
      case 'medicine_reminder':
        return Colors.red[50]!;
      case 'exercise_reminder':
        return Colors.green[50]!;
      case 'weekly_feedback_reminder':
        return Colors.blue[50]!;
      default:
        return Colors.grey[50]!;
    }
  }

  Color _getReminderBorderColor(String type) {
    switch (type) {
      case 'meal_reminder':
        return Colors.orange[200]!;
      case 'medicine_reminder':
        return Colors.red[200]!;
      case 'exercise_reminder':
        return Colors.green[200]!;
      case 'weekly_feedback_reminder':
        return Colors.blue[200]!;
      default:
        return Colors.grey[200]!;
    }
  }

  IconData _getReminderIcon(String type) {
    switch (type) {
      case 'meal_reminder':
        return Icons.restaurant;
      case 'medicine_reminder':
        return Icons.medication;
      case 'exercise_reminder':
        return Icons.fitness_center;
      case 'weekly_feedback_reminder':
        return Icons.feedback;
      default:
        return Icons.notifications;
    }
  }

  Color _getReminderIconColor(String type) {
    switch (type) {
      case 'meal_reminder':
        return Colors.orange[600]!;
      case 'medicine_reminder':
        return Colors.red[600]!;
      case 'exercise_reminder':
        return Colors.green[600]!;
      case 'weekly_feedback_reminder':
        return Colors.blue[600]!;
      default:
        return Colors.grey[600]!;
    }
  }
}
