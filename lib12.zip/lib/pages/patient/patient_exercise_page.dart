import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:intl/intl.dart';
import '../../models/exercise.dart';
import '../../services/exercise_service.dart';

class PatientExercisePage extends StatefulWidget {
  const PatientExercisePage({super.key});

  @override
  State<PatientExercisePage> createState() => _PatientExercisePageState();
}

class _PatientExercisePageState extends State<PatientExercisePage> {
  final ExerciseService _exerciseService = ExerciseService();
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;
  
  List<ExerciseRecommendation> _recommendations = [];
  Map<String, int> _weeklyProgress = {}; // exerciseId -> completed this week
  Map<String, Exercise> _exercises = {}; // exerciseId -> Exercise object
  bool _isLoading = true;
  String? _errorMessage;
  DateTime _currentWeekStart = DateTime.now();

  @override
  void initState() {
    super.initState();
    _currentWeekStart = _getWeekStart(DateTime.now());
    _loadExerciseData();
  }

  DateTime _getWeekStart(DateTime date) {
    return date.subtract(Duration(days: date.weekday - 1));
  }

  Future<void> _loadExerciseData() async {
    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });

    final user = _auth.currentUser;
    if (user == null) {
      setState(() {
        _errorMessage = 'User not authenticated';
        _isLoading = false;
      });
      return;
    }

    try {
      // Load exercise recommendations
      final recSnapshot = await _firestore
          .collection('exercise_recommendations')
          .where('patientId', isEqualTo: user.uid)
          .orderBy('createdAt', descending: true)
          .get();

      List<ExerciseRecommendation> recommendations = [];
      Set<String> allExerciseIds = {};

      for (var doc in recSnapshot.docs) {
        final rec = ExerciseRecommendation.fromMap(doc.data());
        recommendations.add(rec);
        allExerciseIds.addAll(rec.exerciseIds);
      }

      // Load exercise details
      Map<String, Exercise> exercises = {};
      for (String exerciseId in allExerciseIds) {
        final exercise = await _exerciseService.getExerciseById(exerciseId);
        if (exercise != null) {
          exercises[exerciseId] = exercise;
        }
      }

      // Load weekly progress
      await _loadWeeklyProgress(user.uid, allExerciseIds.toList());

        setState(() {
          _recommendations = recommendations;
        _exercises = exercises;
          _isLoading = false;
        });
    } catch (e) {
      setState(() {
        _errorMessage = 'Error loading exercise data: $e';
        _isLoading = false;
      });
    }
  }

  Future<void> _loadWeeklyProgress(String patientId, List<String> exerciseIds) async {
    final weekEnd = _currentWeekStart.add(Duration(days: 7));
    
    try {
      final logsSnapshot = await _firestore
          .collection('exercise_logs')
          .where('patientId', isEqualTo: patientId)
          .where('date', isGreaterThanOrEqualTo: _currentWeekStart.toIso8601String())
          .where('date', isLessThan: weekEnd.toIso8601String())
          .get();

      Map<String, int> progress = {};
      for (String exerciseId in exerciseIds) {
        progress[exerciseId] = 0;
      }

      for (var doc in logsSnapshot.docs) {
        final log = ExerciseLog.fromMap(doc.data());
        if (log.completed && progress.containsKey(log.exerciseId)) {
          progress[log.exerciseId] = progress[log.exerciseId]! + 1;
        }
      }

      setState(() {
        _weeklyProgress = progress;
      });
    } catch (e) {
      print('Error loading weekly progress: $e');
    }
  }

  Future<void> _logExerciseCompletion(String exerciseId, Exercise exercise) async {
    final user = _auth.currentUser;
    if (user == null) return;

    showDialog(
      context: context,
      builder: (context) => _buildExerciseLogDialog(exerciseId, exercise),
    );
  }

  Widget _buildExerciseLogDialog(String exerciseId, Exercise exercise) {
    String difficulty = 'Normal';
    String notes = '';
    bool completed = true;
    
    final difficultyOptions = ['Very Easy', 'Easy', 'Normal', 'Hard', 'Very Hard'];

    return StatefulBuilder(
      builder: (context, setDialogState) => AlertDialog(
        title: Row(
          children: [
            Icon(Icons.fitness_center, color: Colors.green[600]),
            SizedBox(width: 8),
            Expanded(
              child: Text(
                'Log Exercise',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
            ),
          ],
        ),
        content: SizedBox(
          width: double.maxFinite,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Exercise info
              Container(
                padding: EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.green[50],
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: Colors.green[200]!),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      exercise.title,
                      style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                    ),
                    SizedBox(height: 4),
                    Text(
                      '${exercise.duration} minutes • ${exercise.difficulty}',
                      style: TextStyle(fontSize: 12, color: Colors.grey[600]),
                    ),
                  ],
                ),
              ),
              SizedBox(height: 16),
              
              // Completion status
              Text('Did you complete this exercise?', style: TextStyle(fontWeight: FontWeight.bold)),
              SizedBox(height: 8),
              Column(
                children: [
                  RadioListTile<bool>(
                    title: Text('✅ Yes, I completed it'),
                    value: true,
                    groupValue: completed,
                    onChanged: (value) {
                      setDialogState(() {
                        completed = value!;
                      });
                    },
                    contentPadding: EdgeInsets.zero,
                  ),
                  RadioListTile<bool>(
                    title: Text('❌ No, I couldn\'t complete it'),
                    value: false,
                    groupValue: completed,
                    onChanged: (value) {
                      setDialogState(() {
                        completed = value!;
                      });
                    },
                    contentPadding: EdgeInsets.zero,
                  ),
                ],
              ),
              
              if (completed) ...[
                SizedBox(height: 16),
                Text('How difficult was it?', style: TextStyle(fontWeight: FontWeight.bold)),
                SizedBox(height: 8),
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 12),
                  decoration: BoxDecoration(
                    border: Border.all(color: Colors.grey[400]!),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: DropdownButtonHideUnderline(
                    child: DropdownButton<String>(
                      value: difficulty,
                      isExpanded: true,
                      items: difficultyOptions.map((String value) {
                        return DropdownMenuItem<String>(
                          value: value,
                          child: Text(value),
                        );
                      }).toList(),
                      onChanged: (value) {
                        setDialogState(() {
                          difficulty = value!;
                        });
                      },
                    ),
                  ),
                ),
              ],
              
              SizedBox(height: 16),
              Text('Additional notes (optional)', style: TextStyle(fontWeight: FontWeight.bold)),
              SizedBox(height: 8),
              TextField(
                onChanged: (value) => notes = value,
                decoration: InputDecoration(
                  hintText: completed ? 'How did you feel?' : 'What prevented you from completing?',
                  border: OutlineInputBorder(),
                  isDense: true,
                ),
                maxLines: 2,
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              _saveExerciseLog(exerciseId, exercise, completed, difficulty, notes);
            },
            style: ElevatedButton.styleFrom(backgroundColor: Colors.green[600]),
            child: Text('Save Log', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
  }

  Future<void> _saveExerciseLog(
    String exerciseId,
    Exercise exercise,
    bool completed,
    String difficulty,
    String notes,
  ) async {
    final user = _auth.currentUser;
    if (user == null) return;

    final log = {
      'patientId': user.uid,
      'exerciseId': exerciseId,
      'exerciseTitle': exercise.title,
      'date': DateTime.now().toIso8601String(),
      'completed': completed,
      'difficulty': completed ? difficulty : null,
      'notes': notes.isEmpty ? null : notes,
      'timestamp': FieldValue.serverTimestamp(),
    };

    try {
      await _firestore.collection('exercise_logs').add(log);

      // Create notification to doctor
      await _firestore.collection('notifications').add({
        'userId': _recommendations.isNotEmpty ? _recommendations.first.patientId : '',
        'title': completed ? '🏃‍♂️ Exercise Completed' : '⚠️ Exercise Not Completed',
        'message': 'Patient ${completed ? 'completed' : 'did not complete'} ${exercise.title}.',
        'type': 'exercise_log_update',
        'relatedId': exerciseId,
        'patientId': user.uid,
        'exerciseTitle': exercise.title,
        'completed': completed,
        'createdAt': DateTime.now().toIso8601String(),
        'isRead': false,
        'timestamp': FieldValue.serverTimestamp(),
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Exercise log saved and sent to doctor!'),
          backgroundColor: completed ? Colors.green[600] : Colors.orange[600],
          behavior: SnackBarBehavior.floating,
        ),
      );

      // Refresh weekly progress
      await _loadWeeklyProgress(user.uid, _exercises.keys.toList());
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error saving exercise log: $e'),
          backgroundColor: Colors.red[600],
          behavior: SnackBarBehavior.floating,
        ),
      );
    }
  }

  Future<void> _launchVideo(String url) async {
    try {
    final uri = Uri.parse(url);
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    } else {
        throw 'Could not launch $url';
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error opening video: $e'),
          backgroundColor: Colors.red[600],
          behavior: SnackBarBehavior.floating,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.green[50],
      appBar: AppBar(
        title: Text('My Exercises', style: TextStyle(fontWeight: FontWeight.bold)),
        backgroundColor: Colors.green[700],
        foregroundColor: Colors.white,
        elevation: 0,
        actions: [
          IconButton(
            icon: Icon(Icons.refresh),
            onPressed: _loadExerciseData,
            tooltip: 'Refresh',
          ),
        ],
      ),
      body: _isLoading
          ? Center(child: CircularProgressIndicator(color: Colors.green[700]))
          : _errorMessage != null
              ? _buildErrorWidget()
              : _recommendations.isEmpty
                  ? _buildEmptyWidget()
                  : _buildExerciseContent(),
    );
  }

  Widget _buildErrorWidget() {
    return Center(
      child: Padding(
        padding: EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
                children: [
            Icon(Icons.error_outline, size: 64, color: Colors.red[600]),
            SizedBox(height: 16),
            Text(
              _errorMessage!,
              style: TextStyle(fontSize: 16, color: Colors.red[600]),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 24),
            ElevatedButton(
              onPressed: _loadExerciseData,
              style: ElevatedButton.styleFrom(backgroundColor: Colors.green[700]),
              child: Text('Retry', style: TextStyle(color: Colors.white)),
            ),
                ],
              ),
            ),
    );
  }

  Widget _buildEmptyWidget() {
    return Center(
        child: Padding(
        padding: EdgeInsets.all(24),
          child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.fitness_center, size: 64, color: Colors.green[300]),
            SizedBox(height: 16),
              Text(
              'No Exercise Plan Yet',
                style: TextStyle(
                fontSize: 24,
                  fontWeight: FontWeight.bold,
                color: Colors.green[700],
              ),
            ),
            SizedBox(height: 8),
              Text(
              'Your doctor will create a personalized exercise plan for you.',
              style: TextStyle(fontSize: 16, color: Colors.green[600]),
              textAlign: TextAlign.center,
              ),
            ],
          ),
        ),
      );
    }

  Widget _buildExerciseContent() {
    return SingleChildScrollView(
      padding: EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Week progress overview
          _buildWeekProgressCard(),
          SizedBox(height: 20),
          
          // Exercise recommendations
          Text(
            'Your Exercise Plan',
            style: TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
              color: Colors.green[700],
            ),
          ),
          SizedBox(height: 16),
          
          ..._recommendations.map((rec) => _buildRecommendationCard(rec)),
        ],
      ),
    );
  }

  Widget _buildWeekProgressCard() {
    final weekStart = DateFormat('MMM dd').format(_currentWeekStart);
    final weekEnd = DateFormat('MMM dd').format(_currentWeekStart.add(Duration(days: 6)));
    
    return Card(
      elevation: 6,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          gradient: LinearGradient(
            colors: [Colors.green[700]!, Colors.green[500]!],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
      child: Padding(
          padding: EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
              Row(
                children: [
                  Icon(Icons.calendar_today, color: Colors.white, size: 24),
                  SizedBox(width: 12),
                  Text(
                    'Week Progress',
              style: TextStyle(
                      fontSize: 20,
                fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                ],
              ),
              SizedBox(height: 8),
              Text(
                '$weekStart - $weekEnd',
                style: TextStyle(color: Colors.white70, fontSize: 14),
              ),
              SizedBox(height: 16),
              
              // Progress for each exercise
              ..._weeklyProgress.entries.map((entry) {
                final exercise = _exercises[entry.key];
                if (exercise == null) return SizedBox.shrink();
                
                final recommendation = _recommendations.firstWhere(
                  (rec) => rec.exerciseIds.contains(entry.key),
                );
                final targetFreq = recommendation.frequencyPerWeek?[entry.key] ?? 3;
                final completed = entry.value;
                
                return Padding(
                  padding: EdgeInsets.only(bottom: 8),
                  child: Row(
                    children: [
                      Expanded(
                        child: Text(
                          exercise.title,
                          style: TextStyle(color: Colors.white, fontSize: 14),
                        ),
                      ),
                      Text(
                        '$completed/$targetFreq',
                        style: TextStyle(
                          color: completed >= targetFreq ? Colors.greenAccent : Colors.white70,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      SizedBox(width: 8),
                      Icon(
                        completed >= targetFreq ? Icons.check_circle : Icons.schedule,
                        color: completed >= targetFreq ? Colors.greenAccent : Colors.white70,
                        size: 16,
                      ),
                    ],
                  ),
                );
              }).toList(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildRecommendationCard(ExerciseRecommendation recommendation) {
    return Card(
      elevation: 4,
      margin: EdgeInsets.only(bottom: 16),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
              Text(
              'Created: ${DateFormat('MMM dd, yyyy').format(recommendation.createdAt)}',
                style: TextStyle(
                fontSize: 12,
                color: Colors.grey[600],
                  fontWeight: FontWeight.bold,
              ),
            ),
            if (recommendation.notes.isNotEmpty) ...[
              SizedBox(height: 8),
              Container(
                padding: EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.green[50],
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: Colors.green[200]!),
                ),
                child: Text(
                  'Doctor\'s Notes: ${recommendation.notes}',
                  style: TextStyle(fontSize: 14, color: Colors.green[800]),
                ),
              ),
            ],
            SizedBox(height: 16),
            
            // Exercise list
            ...recommendation.exerciseIds.map((exerciseId) {
              final exercise = _exercises[exerciseId];
              if (exercise == null) return SizedBox.shrink();
              
              final targetFreq = recommendation.frequencyPerWeek?[exerciseId] ?? 3;
              final completed = _weeklyProgress[exerciseId] ?? 0;
              
              return _buildExerciseCard(exercise, exerciseId, targetFreq, completed);
            }).toList(),
          ],
        ),
      ),
    );
  }

  Widget _buildExerciseCard(Exercise exercise, String exerciseId, int targetFreq, int completed) {
    final isCompleteForWeek = completed >= targetFreq;
    
    return Card(
      margin: EdgeInsets.only(bottom: 12),
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: Colors.green[100],
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Icon(
                    Icons.fitness_center,
                    color: Colors.green[600],
                    size: 24,
                  ),
                ),
                SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        exercise.title,
              style: TextStyle(
                          fontSize: 16,
                fontWeight: FontWeight.bold,
                          color: Colors.green[700],
                        ),
                      ),
                      Text(
                        '${exercise.duration} min • ${exercise.difficulty}',
                        style: TextStyle(fontSize: 12, color: Colors.grey[600]),
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: isCompleteForWeek ? Colors.green[100] : Colors.orange[100],
                    borderRadius: BorderRadius.circular(12),
                  ),
                          child: Text(
                    '$completed/$targetFreq this week',
                    style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                      color: isCompleteForWeek ? Colors.green[700] : Colors.orange[700],
                            ),
                          ),
                        ),
                      ],
            ),
            SizedBox(height: 12),
            
            Text(
              exercise.description,
              style: TextStyle(fontSize: 14, color: Colors.grey[700]),
            ),
            
            SizedBox(height: 12),
            
            // Action buttons
            Row(
              children: [
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: () => _launchVideo(exercise.videoUrl),
                    icon: Icon(Icons.play_arrow),
                    label: Text('Watch Video'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.blue[600],
                      foregroundColor: Colors.white,
                    ),
                  ),
                ),
                SizedBox(width: 8),
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: () => _logExerciseCompletion(exerciseId, exercise),
                    icon: Icon(Icons.check),
                    label: Text('Log Exercise'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.green[600],
                      foregroundColor: Colors.white,
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

