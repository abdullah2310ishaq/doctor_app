import 'package:doctor_app/pages/doctor/comprehensive_patient_detials.dart';
import 'package:doctor_app/pages/doctor/create_diet.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:intl/intl.dart';
import 'package:doctor_app/pages/doctor/patient_diet_strength_details.dart';

import 'create_prescription.dart';

class PatientDetailsPage extends StatefulWidget {
  final String patientId;
  final String patientName;

  const PatientDetailsPage({
    super.key,
    required this.patientId,
    required this.patientName,
  });

  @override
  State<PatientDetailsPage> createState() => _PatientDetailsPageState();
}

class _PatientDetailsPageState extends State<PatientDetailsPage> {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;

  Map<String, dynamic>? _patientData;
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadPatientDetails();
  }

  String _getStringValue(dynamic value) {
    if (value == null) return 'Not provided';
    if (value is String) return value;
    if (value is Map) return value.toString();

    // Handle timestamp conversion for date of birth
    if (value is int || value is double) {
      try {
        // Check if it's a timestamp in seconds (Firestore timestamp)
        if (value > 1000000000) {
          // Likely a timestamp in seconds
          final date =
              DateTime.fromMillisecondsSinceEpoch((value * 1000).round());
          return DateFormat('MMM dd, yyyy').format(date);
        } else if (value > 1000000000000) {
          // Likely a timestamp in milliseconds
          final date = DateTime.fromMillisecondsSinceEpoch(value.round());
          return DateFormat('MMM dd, yyyy').format(date);
        }
      } catch (e) {
        // If conversion fails, return as string
        return value.toString();
      }
    }

    return value.toString();
  }

  void _loadPatientDetails() async {
    try {
      final doc =
          await _firestore.collection('patients').doc(widget.patientId).get();
      if (doc.exists) {
        setState(() {
          _patientData = doc.data();
          _isLoading = false;
        });
      }
    } catch (e) {
      debugPrint('Error loading patient details: $e');
      setState(() {
        _isLoading = false;
      });
    }
  }

  void _createPrescription() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => CreatePrescriptionPage(
          patientId: widget.patientId,
          patientName: widget.patientName,
          onPrescriptionCreated: () {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                  content:
                      Text('Prescription created for ${widget.patientName}')),
            );
          },
        ),
      ),
    );
  }

  void _createDietPlan() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => CreateDietPlanPage(
          patientId: widget.patientId,
          patientName: widget.patientName,
          onDietPlanCreated: () {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                  content: Text('Diet plan created for ${widget.patientName}')),
            );
          },
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          widget.patientName,
          style: const TextStyle(
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
        backgroundColor: Colors.blue[700],
        elevation: 0,
        flexibleSpace: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [Colors.blue[800]!, Colors.blue[600]!],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
        ),
        actions: [
          IconButton(
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => PatientDietStrengthDetails(
                    patientId: widget.patientId,
                    patientName: widget.patientName,
                  ),
                ),
              );
            },
            icon: const Icon(Icons.assessment, color: Colors.white),
            tooltip: 'Diet & Strength Assessment',
          ),
          PopupMenuButton<String>(
            onSelected: (value) {
              if (value == 'prescribe') {
                _createPrescription();
              } else if (value == 'diet_plan') {
                _createDietPlan();
              }
            },
            itemBuilder: (context) => [
              const PopupMenuItem(
                value: 'prescribe',
                child: Row(
                  children: [
                    Icon(Icons.medical_services, color: Colors.blue),
                    SizedBox(width: 8),
                    Text('Create Prescription'),
                  ],
                ),
              ),
              const PopupMenuItem(
                value: 'diet_plan',
                child: Row(
                  children: [
                    Icon(Icons.restaurant_menu, color: Colors.blue),
                    SizedBox(width: 8),
                    Text('Create Diet Plan'),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _patientData == null
              ? Center(
                  child: Text(
                    'Patient data not found',
                    style: Theme.of(context).textTheme.titleLarge?.copyWith(
                          color: Colors.grey[700],
                        ),
                  ),
                )
              : SingleChildScrollView(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _buildPatientHeader(),
                      const SizedBox(height: 24),
                      _buildQuickActions(),
                      const SizedBox(height: 24),
                      _buildAssessmentStatus(),
                      const SizedBox(height: 24),
                      _buildPersonalInfo(),
                      const SizedBox(height: 24),
                      _buildMedicalHistory(),
                      const SizedBox(height: 24),
                      _buildRecentPrescriptions(),
                      const SizedBox(height: 24),
                      _buildRecentDietPlans(),
                      const SizedBox(height: 24),
                      _buildComplianceAndFeedback(),
                    ],
                  ),
                ),
    );
  }

  Widget _buildPatientHeader() {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Row(
          children: [
            CircleAvatar(
              radius: 40,
              backgroundColor: Colors.blue[100],
              child: Text(
                widget.patientName.substring(0, 1).toUpperCase(),
                style: TextStyle(
                  fontSize: 32,
                  fontWeight: FontWeight.bold,
                  color: Colors.blue[800],
                ),
              ),
            ),
            const SizedBox(width: 20),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    widget.patientName,
                    style: Theme.of(context).textTheme.titleLarge?.copyWith(
                          fontWeight: FontWeight.bold,
                          color: Colors.blue[900],
                        ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    _getStringValue(_patientData!['email']),
                    style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                          color: Colors.grey[600],
                        ),
                  ),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 12,
                          vertical: 6,
                        ),
                        decoration: BoxDecoration(
                          color: _patientData!['profileCompleted'] == true
                              ? Colors.blue[100]
                              : Colors.orange[100],
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Text(
                          _patientData!['profileCompleted'] == true
                              ? 'Profile Complete'
                              : 'Profile Incomplete',
                          style: TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.bold,
                            color: _patientData!['profileCompleted'] == true
                                ? Colors.blue[800]
                                : Colors.orange[800],
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildQuickActions() {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Quick Actions',
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                    fontWeight: FontWeight.bold,
                    color: Colors.blue[900],
                  ),
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: _createPrescription,
                    icon: const Icon(Icons.medical_services),
                    label: const Text('Prescribe'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.blue[600],
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      elevation: 2,
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: _createDietPlan,
                    icon: const Icon(Icons.restaurant_menu),
                    label: const Text('Diet Plan'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.blue[600],
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      elevation: 2,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => PatientDietStrengthDetails(
                            patientId: widget.patientId,
                            patientName: widget.patientName,
                          ),
                        ),
                      );
                    },
                    icon: const Icon(Icons.assessment),
                    label: const Text('Assessment'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.blue[600],
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      elevation: 2,
                    ),
                  ),
                ),
                const SizedBox(width: 12),
              ],
            ),
            const SizedBox(height: 12),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => ComprehensivePatientDetails(
                        patientId: widget.patientId,
                        patientName: widget.patientName,
                      ),
                    ),
                  );
                },
                icon: const Icon(Icons.description),
                label: const Text('Full Report'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.blue[600],
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  elevation: 2,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAssessmentStatus() {
    final hasDetailedAssessment = _patientData!['dietaryHabits'] != null ||
        _patientData!['muscleStrength'] != null ||
        _patientData!['applicationUsability'] != null;

    final hasSimpleAssessment = _patientData!['dietType'] != null ||
        _patientData!['exerciseLevel'] != null ||
        _patientData!['healthGoal'] != null;

    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Assessment Status',
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                    fontWeight: FontWeight.bold,
                    color: Colors.blue[900],
                  ),
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Icon(
                  hasDetailedAssessment ? Icons.check_circle : Icons.cancel,
                  color: hasDetailedAssessment
                      ? Colors.blue[600]
                      : Colors.red[600],
                ),
                const SizedBox(width: 8),
                Text(
                  'Detailed Assessment: ${hasDetailedAssessment ? "Completed" : "Not Completed"}',
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        color: hasDetailedAssessment
                            ? Colors.blue[600]
                            : Colors.red[600],
                        fontWeight: FontWeight.w500,
                      ),
                ),
              ],
            ),
            if (hasDetailedAssessment || hasSimpleAssessment) ...[
              const SizedBox(height: 12),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => PatientDietStrengthDetails(
                          patientId: widget.patientId,
                          patientName: widget.patientName,
                        ),
                      ),
                    );
                  },
                  icon: const Icon(Icons.visibility),
                  label: const Text('View Assessment Details'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.blue[600],
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    elevation: 2,
                  ),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildPersonalInfo() {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Personal Information',
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                    fontWeight: FontWeight.bold,
                    color: Colors.blue[900],
                  ),
            ),
            const SizedBox(height: 16),
            _buildInfoRow('Full Name', _getStringValue(_patientData!['name'])),
            _buildInfoRow('Age', _getStringValue(_patientData!['age'])),
            _buildInfoRow('Gender', _getStringValue(_patientData!['gender'])),
            _buildInfoRow('Phone', _getStringValue(_patientData!['phone'])),
            _buildInfoRow('Email', _getStringValue(_patientData!['email'])),
            _buildInfoRow('Address', _getStringValue(_patientData!['address'])),
          ],
        ),
      ),
    );
  }

  Widget _buildMedicalHistory() {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Medical History Summary',
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                    fontWeight: FontWeight.bold,
                    color: Colors.blue[900],
                  ),
            ),
            const SizedBox(height: 16),
            StreamBuilder<QuerySnapshot>(
              stream: _firestore
                  .collection('appointments')
                  .where('patientId', isEqualTo: widget.patientId)
                  .snapshots(),
              builder: (context, snapshot) {
                final count = snapshot.hasData ? snapshot.data!.docs.length : 0;
                return _buildInfoRow('Total Appointments', count.toString());
              },
            ),
            StreamBuilder<QuerySnapshot>(
              stream: _firestore
                  .collection('prescriptions')
                  .where('patientId', isEqualTo: widget.patientId)
                  .snapshots(),
              builder: (context, snapshot) {
                final count = snapshot.hasData ? snapshot.data!.docs.length : 0;
                return _buildInfoRow('Total Prescriptions', count.toString());
              },
            ),
            StreamBuilder<QuerySnapshot>(
              stream: _firestore
                  .collection('diet_plans')
                  .where('patientId', isEqualTo: widget.patientId)
                  .snapshots(),
              builder: (context, snapshot) {
                final count = snapshot.hasData ? snapshot.data!.docs.length : 0;
                return _buildInfoRow('Total Diet Plans', count.toString());
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildRecentPrescriptions() {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Recent Prescriptions',
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                    fontWeight: FontWeight.bold,
                    color: Colors.blue[900],
                  ),
            ),
            const SizedBox(height: 16),
            StreamBuilder<QuerySnapshot>(
              stream: _firestore
                  .collection('prescriptions')
                  .where('patientId', isEqualTo: widget.patientId)
                  .limit(5)
                  .snapshots(),
              builder: (context, snapshot) {
                if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
                  return Text(
                    'No prescriptions found',
                    style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                          color: Colors.grey[600],
                        ),
                  );
                }

                final docs = snapshot.data!.docs;
                docs.sort((a, b) {
                  final aData = a.data() as Map<String, dynamic>;
                  final bData = b.data() as Map<String, dynamic>;
                  final aDate = aData['date'] ?? '';
                  final bDate = bData['date'] ?? '';
                  return bDate.compareTo(aDate);
                });

                return Column(
                  children: docs.take(5).map((doc) {
                    final data = doc.data() as Map<String, dynamic>;
                    final dateStr = data['date'] ?? '';
                    final medications = data['medications'] as List? ?? [];

                    DateTime? date;
                    try {
                      date = DateTime.parse(dateStr);
                    } catch (e) {
                      date = null;
                    }

                    return Card(
                      margin: const EdgeInsets.only(bottom: 8),
                      color: Colors.blue[50],
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(12.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(
                                  date != null
                                      ? DateFormat('MMM dd, yyyy').format(date)
                                      : 'Date not available',
                                  style: Theme.of(context)
                                      .textTheme
                                      .titleMedium
                                      ?.copyWith(
                                        fontWeight: FontWeight.bold,
                                        color: Colors.blue[900],
                                      ),
                                ),
                                Text(
                                  '${medications.length} medications',
                                  style: Theme.of(context)
                                      .textTheme
                                      .bodyMedium
                                      ?.copyWith(
                                        color: Colors.grey[600],
                                      ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 8),
                            ...medications.map((med) {
                              if (med is Map<String, dynamic>) {
                                return Text(
                                  '• ${med['name'] ?? 'Unknown'} - ${med['dosage'] ?? 'N/A'} (${med['frequency'] ?? 'N/A'})',
                                  style: Theme.of(context).textTheme.bodyMedium,
                                );
                              }
                              return Text(
                                '• $med',
                                style: Theme.of(context).textTheme.bodyMedium,
                              );
                            }).toList(),
                          ],
                        ),
                      ),
                    );
                  }).toList(),
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildRecentDietPlans() {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Recent Diet Plans',
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                    fontWeight: FontWeight.bold,
                    color: Colors.blue[900],
                  ),
            ),
            const SizedBox(height: 16),
            StreamBuilder<QuerySnapshot>(
              stream: _firestore
                  .collection('diet_plans')
                  .where('patientId', isEqualTo: widget.patientId)
                  .limit(3)
                  .snapshots(),
              builder: (context, snapshot) {
                if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
                  return Text(
                    'No diet plans found',
                    style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                          color: Colors.grey[600],
                        ),
                  );
                }

                final docs = snapshot.data!.docs;
                docs.sort((a, b) {
                  final aData = a.data() as Map<String, dynamic>;
                  final bData = b.data() as Map<String, dynamic>;
                  final aDate = aData['startDate'] ?? '';
                  final bDate = bData['startDate'] ?? '';
                  return bDate.compareTo(aDate);
                });

                return Column(
                  children: docs.take(3).map((doc) {
                    final data = doc.data() as Map<String, dynamic>;
                    final startDateStr = data['startDate'] ?? '';
                    final meals = data['meals'] as List? ?? [];

                    DateTime? startDate;
                    try {
                      startDate = DateTime.parse(startDateStr);
                    } catch (e) {
                      startDate = null;
                    }

                    return Card(
                      margin: const EdgeInsets.only(bottom: 8),
                      color: Colors.blue[50],
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(12.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(
                                  startDate != null
                                      ? DateFormat('MMM dd, yyyy')
                                          .format(startDate)
                                      : 'Date not available',
                                  style: Theme.of(context)
                                      .textTheme
                                      .titleMedium
                                      ?.copyWith(
                                        fontWeight: FontWeight.bold,
                                        color: Colors.blue[900],
                                      ),
                                ),
                                Text(
                                  '${meals.length} meals',
                                  style: Theme.of(context)
                                      .textTheme
                                      .bodyMedium
                                      ?.copyWith(
                                        color: Colors.grey[600],
                                      ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 8),
                            ...meals.map((meal) {
                              if (meal is Map<String, dynamic>) {
                                return Text(
                                  '• ${meal['type'] ?? 'Unknown'}: ${meal['name'] ?? 'N/A'}',
                                  style: Theme.of(context).textTheme.bodyMedium,
                                );
                              }
                              return Text(
                                '• $meal',
                                style: Theme.of(context).textTheme.bodyMedium,
                              );
                            }).toList(),
                          ],
                        ),
                      ),
                    );
                  }).toList(),
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildComplianceAndFeedback() {
    return FutureBuilder<List<Widget>>(
      future: _fetchComplianceAndFeedback(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        }
        if (snapshot.hasError) {
          return Text('Error loading compliance: 24{snapshot.error}',
              style: const TextStyle(color: Colors.red));
        }
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: snapshot.data ?? [],
        );
      },
    );
  }

  Future<List<Widget>> _fetchComplianceAndFeedback() async {
    final List<Widget> widgets = [];
    // Fetch meal logs
    final dietSnap = await _firestore
        .collection('diet_plans')
        .where('patientId', isEqualTo: widget.patientId)
        .orderBy('startDate', descending: true)
        .limit(1)
        .get();
    if (dietSnap.docs.isNotEmpty) {
      final dietData = dietSnap.docs.first.data();
      final logs = (dietData['logs'] ?? []) as List;
      widgets.add(Text('Meal Compliance',
          style: TextStyle(
              fontWeight: FontWeight.bold,
              fontSize: 16,
              color: Colors.blue[800])));
      if (logs.isEmpty) {
        widgets.add(const Text('No meal logs yet.'));
      } else {
        widgets.addAll(logs.map((log) {
          return ListTile(
            title: Text(
                '${log['mealType']} - ${log['date']?.substring(0, 10) ?? ''}'),
            subtitle: Text(log['eatenAsPrescribed'] == true
                ? 'Ate as prescribed'
                : 'Ate something else: ${log['alternativeFood'] ?? ''}'),
            leading: Icon(
                log['eatenAsPrescribed'] == true
                    ? Icons.check_circle
                    : Icons.cancel,
                color: log['eatenAsPrescribed'] == true
                    ? Colors.green
                    : Colors.red),
          );
        }).toList());
      }
      widgets.add(const SizedBox(height: 16));
    }
    // Fetch medicine logs
    final presSnap = await _firestore
        .collection('prescriptions')
        .where('patientId', isEqualTo: widget.patientId)
        .orderBy('date', descending: true)
        .limit(1)
        .get();
    if (presSnap.docs.isNotEmpty) {
      final presData = presSnap.docs.first.data();
      final logs = (presData['logs'] ?? []) as List;
      widgets.add(Text('Medicine Compliance',
          style: TextStyle(
              fontWeight: FontWeight.bold,
              fontSize: 16,
              color: Colors.blue[800])));
      if (logs.isEmpty) {
        widgets.add(const Text('No medicine logs yet.'));
      } else {
        widgets.addAll(logs.map((log) {
          return ListTile(
            title: Text(
                '${log['medicationName']} - ${log['date']?.substring(0, 10) ?? ''} (${log['time'] ?? ''})'),
            subtitle: Text(log['taken'] == true
                ? 'Taken'
                : 'Missed: ${log['notes'] ?? ''}'),
            leading: Icon(
                log['taken'] == true ? Icons.check_circle : Icons.cancel,
                color: log['taken'] == true ? Colors.green : Colors.red),
          );
        }).toList());
      }
      widgets.add(const SizedBox(height: 16));
    }
    // Fetch exercise logs
    final exSnap = await _firestore
        .collection('exercise_recommendations')
        .where('patientId', isEqualTo: widget.patientId)
        .orderBy('createdAt', descending: true)
        .limit(1)
        .get();
    if (exSnap.docs.isNotEmpty) {
      final exData = exSnap.docs.first.data();
      final logs = (exData['logs'] ?? []) as List;
      widgets.add(Text('Exercise Compliance',
          style: TextStyle(
              fontWeight: FontWeight.bold,
              fontSize: 16,
              color: Colors.blue[800])));
      if (logs.isEmpty) {
        widgets.add(const Text('No exercise logs yet.'));
      } else {
        widgets.addAll(logs.map((log) {
          return ListTile(
            title: Text(
                '${log['exerciseId']} - ${log['date']?.substring(0, 10) ?? ''}'),
            subtitle: Text(log['completed'] == true
                ? 'Completed'
                : 'Not done: ${log['notes'] ?? ''}'),
            leading: Icon(
                log['completed'] == true ? Icons.check_circle : Icons.cancel,
                color: log['completed'] == true ? Colors.green : Colors.red),
          );
        }).toList());
      }
      widgets.add(const SizedBox(height: 16));
    }
    // Fetch feedback
    final now = DateTime.now();
    final week = now.difference(DateTime(now.year, 1, 1)).inDays ~/ 7 + 1;
    final feedbackSnap = await _firestore
        .collection('feedback')
        .where('patientId', isEqualTo: widget.patientId)
        .orderBy('week', descending: true)
        .limit(4)
        .get();
    widgets.add(Text('Weekly Feedback',
        style: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 16,
            color: Colors.blue[800])));
    if (feedbackSnap.docs.isEmpty) {
      widgets.add(const Text('No feedback submitted yet.'));
    } else {
      widgets.addAll(feedbackSnap.docs.map((doc) {
        final data = doc.data() as Map<String, dynamic>;
        return ListTile(
          title: Text('Week ${data['week']}'),
          subtitle: Text(data['feedback'] ?? ''),
          leading: const Icon(Icons.feedback, color: Colors.blue),
        );
      }));
    }
    return widgets;
  }

  Widget _buildInfoRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12.0),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 120,
            child: Text(
              '$label:',
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                    fontWeight: FontWeight.w500,
                    color: Colors.grey[600],
                  ),
            ),
          ),
          Expanded(
            child: Text(
              value,
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                    fontWeight: FontWeight.w500,
                  ),
            ),
          ),
        ],
      ),
    );
  }

  int _calculateAge(dynamic dateOfBirth) {
    try {
      DateTime birthDate;

      if (dateOfBirth is int || dateOfBirth is double) {
        // Handle timestamp conversion
        if (dateOfBirth > 1000000000) {
          // Likely a timestamp in seconds
          birthDate =
              DateTime.fromMillisecondsSinceEpoch((dateOfBirth * 1000).round());
        } else if (dateOfBirth > 1000000000000) {
          // Likely a timestamp in milliseconds
          birthDate = DateTime.fromMillisecondsSinceEpoch(dateOfBirth.round());
        } else {
          return 0;
        }
      } else if (dateOfBirth is String) {
        birthDate = DateTime.parse(dateOfBirth);
      } else {
        return 0;
      }

      final today = DateTime.now();
      int age = today.year - birthDate.year;
      if (today.month < birthDate.month ||
          (today.month == birthDate.month && today.day < birthDate.day)) {
        age--;
      }
      return age;
    } catch (e) {
      return 0;
    }
  }
}
